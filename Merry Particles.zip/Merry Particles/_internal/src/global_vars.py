class GlobalVars:
    client_w = 1920
    client_h = 1080
    